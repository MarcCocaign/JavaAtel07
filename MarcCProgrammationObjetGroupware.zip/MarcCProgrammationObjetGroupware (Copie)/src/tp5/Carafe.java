package tp5;

public class Carafe {
    // Attributs privés
    private int contenu_;
    private final int capacite_;

    // Constructeur
    public Carafe(int capacite) {
        this.capacite_ = capacite;
        this.contenu_ = 0; // La carafe est initialement vide
    }

    // Méthodes de l'interface publique (à implémenter)
    public void Remplir() {
        // À implémenter
    }

    public void Vider() {
        // À implémenter
    }

    public int Contenu() {
        // À implémenter
        return 0; // Placeholder
    }

    public int Capacite() {
        // À implémenter
        return 0; // Placeholder
    }

    public void Transvaser(Carafe autre) {
        // À implémenter
    }
}

