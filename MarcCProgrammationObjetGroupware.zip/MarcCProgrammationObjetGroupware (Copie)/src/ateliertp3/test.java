package ateliertp3;

public class test {

}
