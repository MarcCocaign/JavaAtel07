package atelier01;

public class SimpleProgramme2 {
	public static void main(String[] args) {
		System.out.println("Marc "); //println = print + retour à la ligne
		System.out.print("Cocaign");
	}
}
