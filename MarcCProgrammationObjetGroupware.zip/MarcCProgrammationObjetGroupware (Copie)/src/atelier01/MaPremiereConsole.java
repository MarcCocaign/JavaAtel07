package atelier01;

public class MaPremiereConsole {
import util.Console;

public static void main(Strong[] args) {
	Console c = new Console();
	c.println("Claude");
	c.println("Montacié");
}
}
}
