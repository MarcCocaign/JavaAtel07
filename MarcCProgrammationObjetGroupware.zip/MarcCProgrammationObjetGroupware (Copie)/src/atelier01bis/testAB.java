package atelier01bis;

public class testAB {
	public static void main(String[] args) {
		System.out.println(A.treize(13));
		System.out.println(A.treize(14));
		System.out.println(A.treize(26));
		System.out.println(B.divise(13));
	}
}


/**
Commentaire
javadoc


https://www.oracle.com/fr/technical-resources/articles/java/javadoc-tool.html
*/