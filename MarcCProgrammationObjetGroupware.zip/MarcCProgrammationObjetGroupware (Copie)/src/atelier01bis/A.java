package atelier01bis;

public class A {
	public static boolean treize(int n) {
		int n1 = n / 13;
		//if ((n1 * 13) == n) return true;
		//else return false;
		return n1 * 13 == n;
	}
}
