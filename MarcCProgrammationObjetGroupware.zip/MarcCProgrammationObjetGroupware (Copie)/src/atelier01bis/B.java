package atelier01bis;

public class B {
	public static int divise(int n) {			
	//	if (A.treize(n) == true) return n / 2;
	//	else return false;
	//}         
        if (A.treize(n)) {
            return n / 2;
        } else {
            return n;
        }
    }
}
