package atelier06Test;

public class test {

}
