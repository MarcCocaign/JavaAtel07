package atelier06Test;

import atelier06.Domesticable;
import atelier06.Felin;

public class ChatTest extends Felin implements Domesticable{
	/** Constructeur */
	public ChatTest (String type) {
		super(type);
	}
	
	public nom(String nom) {
		return null;
	}
	public void domestiquer {
		
	}
}