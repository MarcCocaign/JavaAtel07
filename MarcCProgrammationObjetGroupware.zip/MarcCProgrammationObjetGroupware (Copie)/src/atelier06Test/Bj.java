package atelier06Test;

public class Bj {
    public static void main(String[] args) {
        System.out.println("Bonjour");
    }
}
