package atelier06Test;


public class DomesticableTest {
	/** Domestiquer un animal et lui donner un nom
	 * @param nom nom de l'animal */
	public abstract void domestiquer(String nom);
	
	/** Rend le nom de l'animal
	 * @param nom nom de l'animal */
	public abstract String nom();
	}
}