package atelier07;

import FigureGeometrique;
import java.lang.Comparable;

public class Cercle extends FigureGeometrique implements Comparable{

}
